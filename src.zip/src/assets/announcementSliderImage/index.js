import imageOne from './1.jpeg'
import imageTwo from './2.jpeg'
import imageThree from './3.jpeg'

export const announcementImages = [imageOne, imageTwo,imageThree]
