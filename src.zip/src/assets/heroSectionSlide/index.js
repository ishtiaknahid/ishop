import imageOne from './1.jpg'
import imageTwo from './2.jpg'
import imageThree from './3.jpg'
import imageFour from './4.jpg'
import imageFive from './5.jpg'
export const heroSliderImages = [imageOne, imageTwo , imageThree, imageFour, imageFive]
