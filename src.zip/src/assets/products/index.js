import image from './product.webp';
import chicken from './chicken.png'

const  bookProducts = [
    {
        id: 1, 
        image: image, 
        label: 'Harry Porter',
        price: 40, 
        discount: 10,
        
    },
    {
        id: 2, 
        image: image, 
        label: 'Harry Porter',
        price: 40, 
        discount: 10,
        
    },
    {
        id: 3, 
        image: image, 
        label: 'Harry Porter',
        price: 40, 
        discount: 10,
        
    },
    {
        id: 4, 
        image: image, 
        label: 'Harry Porter',
        price: 40, 
        discount: 10,
        
    },
    {
        id: 5, 
        image: image, 
        label: 'Harry Porter',
        price: 40, 
        discount: 10,
        
    }
]
const  foodProducts = [
    {
        id: 1, 
        image: chicken, 
        label: 'Chiken Fry',
        price: 40, 
        discount: 10,
        shopName: 'Makan Makan'
        
    },
    {
        id: 2, 
        image: chicken, 
        label: 'Chicken Roast',
        price: 40, 
        discount: 10,
        shopName: 'Makan Makan'
        
    },
    {
        id: 3, 
        image: chicken, 
        label: 'Chicken Curry',
        price: 40, 
        discount: 10,
        shopName: 'Makan Makan'
        
    },
]


export {bookProducts, foodProducts}
